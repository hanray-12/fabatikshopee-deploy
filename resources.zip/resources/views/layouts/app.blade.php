<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>FabatikShopee</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body class="bg-gray-100 text-gray-800">

<!-- NAVBAR -->
<nav class="bg-white shadow sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between gap-6">

        <!-- LOGO -->
        <a href="{{ route('home') }}" class="text-xl font-bold whitespace-nowrap text-red-600">
            FabatikShopee ✨
        </a>

        <!-- SEARCH -->
        <form action="{{ route('home') }}" method="GET" class="flex-1 max-w-xl hidden md:block">
            <input
                type="text"
                name="q"
                value="{{ request('q') }}"
                placeholder="Cari produk..."
                class="w-full border rounded-lg px-4 py-2 focus:ring focus:ring-red-200 focus:outline-none"
            >
        </form>

        <!-- RIGHT MENU -->
        <div class="flex items-center gap-4">

            @auth
                {{-- ================= CART ================= --}}
                @php
                    $cart = session('cart', []);
                    $cartCount = collect($cart)->sum('quantity');
                @endphp

                <a href="{{ route('cart.index') }}" class="relative font-semibold">
                    🛒 Cart
                    @if($cartCount > 0)
                        <span class="absolute -top-2 -right-3 bg-red-600 text-white text-xs px-2 rounded-full">
                            {{ $cartCount }}
                        </span>
                    @endif
                </a>
                {{-- ======================================= --}}

                <!-- ADMIN -->
                @if(auth()->user()->role === 'admin')
                    <a href="{{ route('admin.dashboard') }}"
                       class="bg-red-600 text-white px-3 py-2 rounded hover:bg-red-700">
                        ⚙ Admin
                    </a>
                @endif

                <!-- USER DROPDOWN -->
                <div class="relative group">
                    <button class="font-semibold">
                        {{ auth()->user()->name }}
                    </button>

                    <div class="absolute right-0 mt-2 w-40 bg-white shadow rounded hidden group-hover:block">
                        <a href="{{ route('orders.index') }}"
                           class="block px-4 py-2 hover:bg-gray-100">
                            Pesanan
                        </a>

                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <button class="w-full text-left px-4 py-2 hover:bg-gray-100">
                                Logout
                            </button>
                        </form>
                    </div>
                </div>
            @else
                <a href="{{ route('login') }}" class="font-semibold">Login</a>
                <a href="{{ route('register') }}"
                   class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                    Register
                </a>
            @endauth

        </div>
    </div>
</nav>

<!-- CONTENT -->
<main class="max-w-7xl mx-auto py-8 px-6">
    @yield('content')
</main>

</body>
</html>
