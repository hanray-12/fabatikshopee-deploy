<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-gray-100">

<div class="flex min-h-screen">

    {{-- SIDEBAR --}}
    <aside class="w-64 bg-gray-900 text-white">
        <div class="p-4 text-xl font-bold border-b border-gray-700">
            ADMIN
        </div>

        <nav class="p-4 space-y-2">
            <a href="{{ route('admin.dashboard') }}"
               class="block px-3 py-2 rounded
               {{ request()->routeIs('admin.dashboard') ? 'bg-gray-700' : 'hover:bg-gray-800' }}">
                Dashboard
            </a>

            <a href="{{ route('admin.products.index') }}"
               class="block px-3 py-2 rounded
               {{ request()->routeIs('admin.products.*') ? 'bg-gray-700' : 'hover:bg-gray-800' }}">
                Produk
            </a>

            <a href="{{ route('admin.orders.index') }}"
               class="block px-3 py-2 rounded
               {{ request()->routeIs('admin.orders.*') ? 'bg-gray-700' : 'hover:bg-gray-800' }}">
                Order
            </a>
        </nav>
    </aside>

    {{-- CONTENT --}}
    <main class="flex-1 p-6">
        <x-alert />
        @yield('content')
    </main>

</div>

</body>
</html>
