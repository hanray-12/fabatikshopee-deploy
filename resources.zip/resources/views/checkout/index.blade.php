@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto px-6">

    <h1 class="text-2xl font-bold mb-6">🧾 Checkout</h1>

    @php
        $total = 0;
    @endphp

    <div class="bg-white rounded shadow p-6 mb-6">
        @foreach($cartItems as $item)
            @php
                $subtotal = $item['price'] * $item['quantity'];
                $total += $subtotal;
            @endphp

            <div class="flex justify-between border-b py-3">
                <div>
                    <p class="font-semibold">{{ $item['name'] }}</p>
                    <p class="text-sm text-gray-500">
                        Qty: {{ $item['quantity'] }}
                    </p>
                </div>

                <div class="font-semibold">
                    Rp {{ number_format($subtotal,0,',','.') }}
                </div>
            </div>
        @endforeach
    </div>

    {{-- TOTAL --}}
    <div class="bg-white rounded shadow p-4 mb-6 flex justify-between">
        <span class="font-bold text-lg">Total</span>
        <span class="font-bold text-lg text-red-600">
            Rp {{ number_format($total,0,',','.') }}
        </span>
    </div>

    <form action="{{ route('checkout.process') }}" method="POST">
        @csrf
        <button class="w-full bg-green-600 text-white py-3 rounded hover:bg-green-700">
            ✅ Proses Checkout
        </button>
    </form>

</div>
@endsection
