@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto px-4">

    {{-- HEADER --}}
    <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6 gap-2">
        <h1 class="text-2xl md:text-3xl font-bold">
            Welcome To FabatikShopee ✨
        </h1>

        @if(request('search'))
            <p class="text-sm text-gray-500">
                Hasil pencarian:
                <span class="font-semibold">"{{ request('search') }}"</span>
            </p>
        @endif
    </div>

    {{-- EMPTY STATE --}}
    @if ($products->count() === 0)
        <div class="bg-white p-10 rounded-xl shadow text-center text-gray-500">
            Produk belum tersedia 😢
        </div>
    @else

        {{-- PRODUCT GRID (LEBIH KECIL & RAPET) --}}
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">

            @foreach ($products as $product)
                <a href="{{ route('products.show', $product) }}"
                   class="group bg-white rounded-lg overflow-hidden border hover:shadow-lg transition">

                    {{-- IMAGE --}}
                    <div class="h-36 bg-gray-100 overflow-hidden relative">
                        @if ($product->image)
                            <img src="{{ asset('storage/' . $product->image) }}"
                                 alt="{{ $product->name }}"
                                 class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
                        @else
                            <div class="h-full flex items-center justify-center text-gray-400 text-sm">
                                No Image
                            </div>
                        @endif

                        {{-- STOCK BADGE --}}
                        @if($product->stock <= 0)
                            <span class="absolute top-2 left-2 bg-red-600 text-white text-[10px] px-2 py-0.5 rounded">
                                Habis
                            </span>
                        @endif
                    </div>

                    {{-- CONTENT --}}
                    <div class="p-3 space-y-0.5">
                        <h2 class="font-semibold text-sm truncate">
                            {{ $product->name }}
                        </h2>

                        <p class="text-xs text-gray-500">
                            Stok: {{ $product->stock }}
                        </p>

                        <p class="font-bold text-green-600 text-sm">
                            Rp {{ number_format($product->price, 0, ',', '.') }}
                        </p>
                    </div>

                </a>
            @endforeach

        </div>

        {{-- PAGINATION --}}
        <div class="mt-8">
            {{ $products->withQueryString()->links() }}
        </div>

    @endif

</div>
@endsection
