<x-admin-layout>
    <div class="p-6">

        <!-- HEADER -->
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold">
                Detail Order #{{ $order->id }}
            </h1>

            <x-status-badge :status="$order->status" />
        </div>

        <!-- INFO USER -->
        <div class="bg-white rounded shadow p-4 mb-6">
            <p><strong>Nama User:</strong> {{ $order->user->name }}</p>
            <p><strong>Email:</strong> {{ $order->user->email }}</p>
            <p><strong>Tanggal:</strong> {{ $order->created_at->format('d M Y H:i') }}</p>
        </div>

        <!-- TABLE ITEMS -->
        <div class="bg-white rounded shadow overflow-x-auto">
            <table class="w-full border">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="p-3 text-left">Produk</th>
                        <th class="p-3 text-center">Qty</th>
                        <th class="p-3 text-right">Harga</th>
                        <th class="p-3 text-right">Subtotal</th>
                    </tr>
                </thead>

                <tbody>
                    @foreach ($order->items as $item)
                        <tr class="border-t">
                            <td class="p-3">{{ $item->product->name }}</td>
                            <td class="p-3 text-center">{{ $item->quantity }}</td>
                            <td class="p-3 text-right">
                                Rp {{ number_format($item->price,0,',','.') }}
                            </td>
                            <td class="p-3 text-right font-semibold">
                                Rp {{ number_format($item->price * $item->quantity,0,',','.') }}
                            </td>
                        </tr>
                    @endforeach
                </tbody>

                <tfoot>
                    <tr class="bg-gray-50 border-t">
                        <td colspan="3" class="p-4 text-right font-bold">Total</td>
                        <td class="p-4 text-right font-bold text-green-600">
                            Rp {{ number_format($order->total_price,0,',','.') }}
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>

        <!-- UPDATE STATUS -->
        <div class="bg-white rounded shadow p-6 mt-6">
            <h2 class="font-semibold mb-4">Ubah Status Pesanan</h2>

            @if ($order->status !== 'shipped')
                <form method="POST"
                      action="{{ route('admin.orders.update', $order) }}"
                      class="flex items-center gap-4">

                    @csrf
                    @method('PUT')

                    <select name="status"
                            class="border rounded px-4 py-2"
                            required>
                        <option value="pending" @selected($order->status === 'pending')>Pending</option>
                        <option value="paid" @selected($order->status === 'paid')>Paid</option>
                        <option value="shipped" @selected($order->status === 'shipped')>Shipped</option>
                    </select>

                    <button type="submit"
                            class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                        Update Status
                    </button>
                </form>
            @else
                <p class="text-gray-500 italic">
                    Order sudah dikirim, status tidak dapat diubah.
                </p>
            @endif
        </div>

    </div>
</x-admin-layout>
