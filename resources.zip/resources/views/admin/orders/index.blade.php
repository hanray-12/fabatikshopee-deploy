@extends('layouts.admin')

@section('content')

<h1 class="text-2xl font-bold mb-6">Daftar Pesanan</h1>

<div class="bg-white shadow rounded overflow-x-auto">
    <table class="w-full border">
        <thead class="bg-gray-100">
            <tr>
                <th class="p-3">ID</th>
                <th class="p-3">User</th>
                <th class="p-3">Total</th>
                <th class="p-3">Status</th>
                <th class="p-3">Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach($orders as $order)
            <tr class="border-t">
                <td class="p-3">#{{ $order->id }}</td>
                <td class="p-3">{{ $order->user->name }}</td>
                <td class="p-3">Rp {{ number_format($order->total_price) }}</td>
                <td class="p-3">
                   <x-status-badge :status="$order->status" />

                </td>
                <td class="p-3">
                    <a href="{{ route('admin.orders.show', $order) }}"
                       class="text-blue-600 hover:underline">
                        Detail
                    </a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>

@endsection
