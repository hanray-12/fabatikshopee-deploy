@extends('layouts.app')

@section('content')
<div class="max-w-5xl mx-auto p-6">

    <div class="bg-white shadow rounded p-6 grid grid-cols-1 md:grid-cols-2 gap-6">

        <div>
            @if($product->image)
                <img src="{{ asset('storage/'.$product->image) }}"
                     class="w-full h-80 object-cover rounded">
            @else
                <div class="h-80 bg-gray-200 flex items-center justify-center">
                    No Image
                </div>
            @endif
        </div>

        <div>
            <h1 class="text-2xl font-bold mb-2">{{ $product->name }}</h1>
            <p class="text-gray-500">Stok: {{ $product->stock }}</p>

            <p class="text-2xl font-bold text-green-600 my-4">
                Rp {{ number_format($product->price,0,',','.') }}
            </p>

            <p class="mb-6">{{ $product->description }}</p>

            <form action="{{ route('cart.add', $product) }}" method="POST">
                @csrf
                <button class="bg-green-600 text-white px-6 py-2 rounded">
                    + Tambah ke Keranjang
                </button>
            </form>
        </div>

    </div>
</div>
@endsection
