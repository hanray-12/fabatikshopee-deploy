@extends('layouts.app')

@section('content')
<div class="max-w-5xl mx-auto px-6">

<h1 class="text-2xl font-bold mb-6">📦 Pesanan</h1>

<table class="w-full bg-white shadow rounded">
    <thead>
        <tr class="border-b">
            <th class="p-3">ID</th>
            <th class="p-3">Tanggal</th>
            <th class="p-3">Total</th>
            <th class="p-3">Status</th>
        </tr>
    </thead>
    <tbody>
        @foreach($orders as $order)
        <tr class="border-t text-center">
            <td class="p-3">{{ $order->id }}</td>
            <td class="p-3">{{ $order->created_at->format('d-m-Y') }}</td>

            {{-- FIX: totalnya ambil dari total_price --}}
            <td class="p-3">Rp {{ number_format($order->total_price, 0, ',', '.') }}</td>

            <td class="p-3">{{ ucfirst($order->status) }}</td>
        </tr>
        @endforeach
    </tbody>
</table>

</div>
@endsection
