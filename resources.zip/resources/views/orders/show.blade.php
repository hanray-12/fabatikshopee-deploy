@extends('layouts.app')

@section('content')
<div class="max-w-5xl mx-auto py-8">
    <h1 class="text-2xl font-bold mb-4">
        Detail Pesanan #{{ $order->id }}
    </h1>

    <div class="mb-4">
        <x-status-badge :status="$order->status" />
    </div>

    <p class="mb-6 text-gray-600">
        Tanggal: {{ $order->created_at->format('d-m-Y') }}
    </p>

    <table class="w-full border">
        <thead class="bg-gray-100">
            <tr>
                <th class="p-2">Produk</th>
                <th class="p-2">Harga</th>
                <th class="p-2">Qty</th>
                <th class="p-2">Subtotal</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($order->items as $item)
            <tr class="border-t text-center">
                <td class="p-2">{{ $item->product->name }}</td>
                <td class="p-2">Rp {{ number_format($item->price,0,',','.') }}</td>
                <td class="p-2">{{ $item->quantity }}</td>
                <td class="p-2">
                    Rp {{ number_format($item->price * $item->quantity,0,',','.') }}
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <div class="mt-6 text-right font-bold text-xl">
        Total: Rp {{ number_format($order->total_price,0,',','.') }}
    </div>
</div>
@endsection
