@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto px-6">

    <h1 class="text-2xl font-bold mb-6">🛒 Keranjang</h1>

    @if(count($cartItems) === 0)
        <div class="bg-white p-6 rounded shadow text-center text-gray-500">
            Keranjang masih kosong
        </div>
    @else
        @php
            $total = 0;
        @endphp

        @foreach($cartItems as $id => $item)
            @php
                $subtotal = $item['price'] * $item['quantity'];
                $total += $subtotal;
            @endphp

            <div class="bg-white p-4 mb-4 rounded shadow flex justify-between items-center">
                <div>
                    <h2 class="font-semibold">{{ $item['name'] }}</h2>
                    <p>Harga: Rp {{ number_format($item['price'], 0, ',', '.') }}</p>
                    <p>Qty: {{ $item['quantity'] }}</p>
                    <p class="font-semibold mt-1">
                        Subtotal: Rp {{ number_format($subtotal, 0, ',', '.') }}
                    </p>
                </div>

                <form action="{{ route('cart.remove', $id) }}" method="POST">
                    @csrf
                    @method('DELETE')
                    <button class="text-red-600 hover:underline">
                        Hapus
                    </button>
                </form>
            </div>
        @endforeach

        {{-- TOTAL --}}
        <div class="bg-white p-4 rounded shadow flex justify-between items-center mt-6">
            <span class="text-lg font-bold">Total</span>
            <span class="text-lg font-bold text-red-600">
                Rp {{ number_format($total, 0, ',', '.') }}
            </span>
        </div>

        {{-- CHECKOUT --}}
        <div class="mt-6 text-right">
            <a href="{{ route('checkout.index') }}"
               class="inline-block bg-green-600 text-white px-6 py-3 rounded hover:bg-green-700">
                Checkout
            </a>
        </div>
    @endif

</div>
@endsection
