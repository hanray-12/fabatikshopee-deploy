<?php

namespace App\Http\Controllers;

use App\Models\Product;

class CartController extends Controller
{
    public function index()
    {
        $cartItems = session()->get('cart', []);

        return view('cart.index', compact('cartItems'));
    }

    public function add(Product $product)
    {
        $cart = session()->get('cart', []);

        $cart[$product->id] = [
            'name'     => $product->name,
            'price'    => $product->price,
            'quantity' => isset($cart[$product->id])
                ? $cart[$product->id]['quantity'] + 1
                : 1,
        ];

        session()->put('cart', $cart);

        return redirect()->back()->with('success', 'Produk ditambahkan ke keranjang');
    }

    public function remove($id)
    {
        $cart = session()->get('cart', []);

        unset($cart[$id]);

        session()->put('cart', $cart);

        return redirect()->back()->with('success', 'Produk dihapus');
    }
}
