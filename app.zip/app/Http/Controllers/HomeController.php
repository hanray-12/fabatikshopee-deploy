<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(Request $request)
    {
        // Support dua nama parameter: search (baru) & q (lama)
        $search = $request->input('search');
        if ($search === null) {
            $search = $request->input('q');
        }

        $query = Product::query();

        if (!empty($search)) {
            $query->where('name', 'like', '%' . $search . '%');
        }

        // Pagination + biar query string (search) ikut kebawa saat pindah page
        $products = $query->latest()->paginate(8)->withQueryString();

        return view('home', [
            'products' => $products,
            'search' => $search
        ]);
    }
}
